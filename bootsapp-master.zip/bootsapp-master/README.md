# BootsApp
A simple bootstrap template contains basic pages such as home page, about page, pricing page, login and signup page.
You can visit the website [here](https://sheikh005.github.io/bootsapp/home.html).

>The project is completely open source and free to use for anyone and also anyone can make changes to it. Also the name bootsapp is not copyrighted its just a random name choosen by the developer.

Following libraries are used in the development of the project
 - Bootstrap 4
 - Scrollreveal.js
 - Fontawesome icons

Images are taken from the [
Unsplash.com](https://unsplash.com) as there is no copyright issues for them. 
